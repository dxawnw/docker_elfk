分为Server端和Client端
其中Server端所有文件在./server/中，执行以下指令启动
java -cp log4j-1.2.17.jar org.apache.log4j.net.SocketServer 4560 log4jserver.properties lcf/
指令意义：开启Server端日志服务端口4560,使用全局配置文件log4jserver.properties和专用配置文件（与Client对应）

Client端将war包放到tomcat解压后启动tomcat
浏览器访问http://localhost:8080/testLog4j/?log=somelog
意义：记录日志：somelog

